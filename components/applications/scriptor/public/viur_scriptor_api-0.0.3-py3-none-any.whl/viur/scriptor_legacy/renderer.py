class Json:
    def __str__(self):
        return "json"


class Vi:
    def __str__(self):
        return "vi"


json = Json()
vi = Vi()
