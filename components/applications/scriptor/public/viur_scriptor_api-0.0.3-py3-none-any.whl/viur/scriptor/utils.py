import types


def extract_items(data: list[...] | dict[...], selectors: list[str | int | types.EllipsisType, ...], join: str = None):
    """
    extracts items from a data-structure using a list of selectors

    :param data: the data to extract from
    :param selectors: the selectors to extract the data
    :param join: the string with which items should be joined
    :return: extracted data
    """
    assert isinstance(selectors, list)
    assert isinstance(data, (list, dict))
    element = data
    while selectors:
        selector, *selectors = selectors
        if selector is Ellipsis:
            if join:
                return join.join(str(extract_items(i, selectors, join=join)) for i in element)
            else:
                return [extract_items(i, selectors, join=join) for i in element]
        element = element[selector]
    return element


def map_extract_items(data: list[...] | dict[...],
                      selector_mapping: dict[str, list[str | int | types.EllipsisType, ...]], join=None):
    """
    extracts items from a data-structure using a mapping of lists of selectors

    :param data: the data to extract from
    :param selector_mapping: the selector-mapping to extract the data
    :param join: the string with which items should be joined
    :return: a dictionary of the extracted data
    """
    assert isinstance(selector_mapping, dict)
    assert isinstance(data, (list, dict))
    result = {}
    for key, selectors in selector_mapping.items():
        result[key] = extract_items(data, selectors, join=join)
    return result
