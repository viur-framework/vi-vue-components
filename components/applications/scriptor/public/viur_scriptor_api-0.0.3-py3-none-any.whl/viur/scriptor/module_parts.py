from ._utils import join_url
import typing


class BaseModule:
    def __init__(self, name: str, parent):
        super().__init__()
        self._name = name
        self._routes = {}
        self._parent = parent

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str):
        self._name = value

    def register_route(self, name: str, method: object):
        self._routes[name] = method

    @staticmethod
    def _build_url(action: str, url: str, module: str, group: str = "", key: str = ""):
        _url = url
        if not _url:
            if not module:
                raise ValueError("You need to set an url or use the module parameter.")
            _url = [module, action]
            if group:
                _url.append(group)
            if key:
                _url.append(key)
        return join_url(_url)

    def __getattr__(self, name: str):
        if ret := self._routes.get(name, None):
            return ret
        raise AttributeError(f"""'{self.__class__.__name__}' object hast no attribute '{name}'""")

    async def preview(self, params: dict = None, group: str = "", **kwargs):
        _url = kwargs.get('url', '')
        _renderer = kwargs.get('renderer', '')
        url = self._build_url(action="preview", url=_url, module=self._name, group=group)
        return await self._parent.viur_request("SECURE_POST", url, params, renderer=_renderer)

    async def structure(self, group: str = "", **kwargs):
        if 'url' in kwargs:
            _url = kwargs['url']
            del kwargs['url']
        else:
            _url = ''
        url = self._build_url(action="structure", url=_url, module=self._name, group=group)
        return await self._parent.viur_request("GET", url, **kwargs)

    async def view(self, key: str, group: str = "", **kwargs) -> dict:
        if 'url' in kwargs:
            _url = kwargs['url']
            del kwargs['url']
        else:
            _url = ''
        url = self._build_url(action="view", url=_url, module=self._name, group=group, key=key)
        res = await self._parent.viur_request("GET", url, **kwargs)
        if res:
            return res['values']
        else:
            return res

    async def edit(self, key: str = "", params: dict = None, group: str = "", **kwargs):
        _url = kwargs.get('url', '')
        _renderer = kwargs.get('renderer', '')
        url = self._build_url(action="edit", url=_url, module=self._name, group=group, key=key)
        return await self._parent.viur_request("SECURE_POST", url, params=params, renderer=_renderer)


class SingletonModule(BaseModule):
    def edit(self, params: dict = None, group: str = "", **kwargs):  # without key
        return super().edit(module=self._name, params=params, group=group, **kwargs)


class ExtendedModule(BaseModule):

    async def list(self, params: dict = None, group: str = '', **kwargs):
        if not params:
            params = {}

        _url = kwargs.get('url', '')
        _renderer = kwargs.get('renderer', '')

        if not _url:
            _url = [self._name, "list"]
            if group:
                _url.append(group)
            _url = join_url(_url)

        batch = []
        cursor = None
        fetched = False

        while True:
            for i in batch:
                yield i
            if fetched and not cursor:
                return
            if cursor:
                params["cursor"] = cursor
            ret = await self._parent.viur_request("GET", _url, params, _renderer)
            fetched = True
            if not ret:
                return
            batch = ret['skellist']
            # batch.reverse()
            cursor = ret['cursor']
            if not batch:
                cursor = None

    async def add(self, params: dict = None, group: str = "", **kwargs):
        _url = kwargs.get('url', '')
        _renderer = kwargs.get('renderer', '')
        url = self._build_url(action='add', url=_url, module=self._name, group=group)
        return await self._parent.viur_request("SECURE_POST", url=url, params=params, renderer=_renderer)

    async def delete(self, key: str, params: dict = None, group: str = "", **kwargs):
        _url = kwargs.get('url', '')
        _renderer = kwargs.get('renderer', '')
        url = self._build_url(action='delete', url=_url, module=self._name, group=group, key=key)
        return await self._parent.viur_request("SECURE_POST", url=url, params=params, renderer=_renderer)


class ListModule(ExtendedModule):
    async def for_each(self, callback: callable, params: dict = None, **kwargs):
        async for entry in self.list(params=params, **kwargs):
            callback(entry)


class TreeModule(ExtendedModule):
    async def list_root_nodes(self, **kwargs):
        return await self._parent.viur_request("GET", f"/{self.name}/listRootNodes", **kwargs)

    async def move(self, key: str, parentNode: str, **kwargs):
        return await self._parent.viur_request("SECURE_POST", f"/{self.name}/move", params={
            "key": key,
            "parentNode": parentNode
        }, **kwargs)

    async def for_each(self, callback: callable, root_node_key: str = None, params: dict = None, **kwargs):
        async def download(key: str, group: str | list[str] = ['node', 'leaf']):
            if isinstance(group, list):
                for grp in group:
                    await download(key, grp)
                return

            _params = {"parententry": key}
            if params:
                _params.update(params)

            async for entry in self.list(group=group, params=_params, **kwargs):
                cb = callback(group, entry)
                if isinstance(cb, typing.Coroutine):
                    await cb
                # Check if this is a node
                if group == "node":
                    await download(entry["key"])

        if root_node_key:
            root_nodes = [root_node_key]
        else:
            root_nodes = self.list_root_nodes(**kwargs)

        for root_node in root_nodes:
            await download(root_node["key"])


class Method:
    def __init__(self, name: str, module: BaseModule, methods: list[str] | None = None,
                 skey: str = None, parent: bool = True):
        if methods is None:
            methods = []
        self._name: str = name
        self._methods: list[str] = [method for method in methods if method != "HEAD"]

        self._module: BaseModule = module
        self._skey = skey  # supports skey?
        self._parent = parent

        self._attr = None
        if methods:
            if parent:
                self._attr = {
                    option.lower(): Method(name, module, [option.lower()], skey, False)
                    for option in methods
                }

    @property
    def methods(self):
        return [method.lower() for method in self._methods]

    @property
    def name(self):
        return self._name

    def support_method(self, name: str) -> bool:
        return name.lower() in self.methods

    def is_supporting_multiple_methods(self):
        return len(self.methods) > 1

    async def call(self, *args, **kwargs):
        route = f"/{self._module.name}/{self._name}"

        method = "GET"
        if not self.is_supporting_multiple_methods():  ## Multiple options
            method = self.methods[0]

        if self.support_method(method):
            if self._attr:
                if method.lower() in self._attr:
                    return self._attr[method.lower()](*args, **kwargs)

        renderer = kwargs.get("scriptor_renderer", "json")
        if "scriptor_renderer" in kwargs:
            kwargs.pop("scriptor_renderer")

        result = None
        method = method.upper()
        if method == "POST":
            if self._skey:
                result = await self._module._parent.viur_request("SECURE_POST", route, params=kwargs,
                                                                 renderer=renderer)
            else:
                result = await self._module._parent.viur_request("POST", route, *args, params=kwargs,
                                                                 renderer=renderer)
        else:
            if method in ("GET", "DELETE", "PATCH", "PUT"):
                result = await self._module._parent.viur_request(method, route, *args, params=kwargs,
                                                                 renderer=renderer)
        return result

    def __getattr__(self, name: str):
        if self._attr:
            if name in self._attr:
                return self._attr[name]
        raise AttributeError(f"""'{self.__class__.__name__}' object hast no attribute '{name}'""")
