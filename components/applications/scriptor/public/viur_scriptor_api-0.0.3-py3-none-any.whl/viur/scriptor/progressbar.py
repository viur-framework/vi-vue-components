from ._utils import is_pyodide_context

if is_pyodide_context():
    import js


class ProgressBar:
    if is_pyodide_context():
        @staticmethod
        def set(percent: int = 0, current_step: int = -1, total_steps: int = -1, text: str = ""):
            js.self.postMessage(type="progressbar", total=percent, step=current_step, max_step=total_steps, txt=text)
    else:
        @staticmethod
        def set(percent: int = 0, current_step: int = -1, total_steps: int = -1, text: str = ""):
            print(f"""Step {current_step}/{total_steps} ({percent}%): {text}""")

    if is_pyodide_context():
        @staticmethod
        def unset():
            js.self.postMessage(type="progressbar", total=100, step=-1, max_step=-1, txt="")
    else:
        @staticmethod
        def unset():
            pass
